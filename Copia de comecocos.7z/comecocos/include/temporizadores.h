/*-------------------------------------
temporizadores.h
-------------------------------------*/

extern void HabilitarIntTemp();
extern void DeshabilitarIntTemp();
extern void IntTemp();
extern int tespera;
extern int seg;
